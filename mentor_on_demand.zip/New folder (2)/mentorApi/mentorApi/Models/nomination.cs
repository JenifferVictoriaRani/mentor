﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace mentorApi.Models
{
    public class nomination
    {
        [Key]
        public int Id { get; set; }
       
        public string username { get; set; }
        public decimal ContactNumber { get; set; }
        public string sk_Name { get; set; }
    }
}

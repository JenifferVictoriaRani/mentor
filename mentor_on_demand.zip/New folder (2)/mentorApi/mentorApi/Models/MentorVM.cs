﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace mentorApi.Models
{
    public class MentorVM
    {
        [Key]
        public int Id { get; set; }
        public string SkillName { get; set; }
        public decimal? SelfRating { get; set; }
        public int? YearsOfExperience { get; set; }
        public int? TrainngDelivered { get; set; }
        public string FacilitiesOffered { get; set; }
    }
}

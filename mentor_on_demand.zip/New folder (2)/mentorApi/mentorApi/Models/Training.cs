﻿using System;
using System.Collections.Generic;

namespace mentorApi.Models
{
    public partial class Training
    {
        public int Id { get; set; }
        public int? Uid { get; set; }
        public int? Mid { get; set; }
        public int? Sid { get; set; }
        public string Status { get; set; }

        public Mentor M { get; set; }
        public Skills S { get; set; }
        public UserDetails U { get; set; }
    }
}

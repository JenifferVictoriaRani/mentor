﻿using System;
using System.Collections.Generic;

namespace mentorApi.Models
{
    public partial class MentorSkills
    {
        public int Id { get; set; }
        public int? Mid { get; set; }
        public int? Sid { get; set; }
        public decimal? MsSelfRating { get; set; }
        public int? MsYearsOfExperience { get; set; }
        public int? MsTrainngDelivered { get; set; }
        public string MsFacilitiesOffered { get; set; }

        public Mentor M { get; set; }
        public Skills S { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using mentorApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace mentorApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class mentorController : ControllerBase
    {
        mentor_on_demandContext m = new mentor_on_demandContext();

        // GET: api/mentor
        [Route("getskill")]
        [HttpGet]
        public IEnumerable<Skills> Get()
        {
            try { 
            return m.Skills.ToList();
            }
            catch (Exception e) {
                return null;

            }
        }
        [Route("getMentorSkill")]
        [HttpGet]
        public IEnumerable<MentorSkills> getMentorSkill()
        {
            try { 
            return m.MentorSkills.ToList();
            }
            catch (Exception e) {
                return null;

            }
        }

        // GET: api/mentor/5
        [Route("getProfile/{id}")]
        [HttpGet(Name = "Get")]
        public IEnumerable<MentorVM> Get(int id)
        {
            try { 
            return m.MentorVM.FromSql("mentorProfile " + id).ToList();
            }
            catch (Exception e) {
                return null;
            }
        }
        [Route("getNomination/{id}")]
        [HttpGet(Name = "Get")]
        public IEnumerable<nomination> GetNomination(int id)
        {
            try { 
            return m.nomination.FromSql("nomination " + id).ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        // POST: api/mentor
        [HttpPost]
        public void Post([FromBody] MentorSkills value)
        {
            try { 
            m.MentorSkills.Add(value);
            m.SaveChanges();
            }
            catch (Exception e)
            {
               
            }
        }

        // PUT: api/mentor/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

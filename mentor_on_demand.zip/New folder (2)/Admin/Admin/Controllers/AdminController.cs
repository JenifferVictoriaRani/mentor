﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Admin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        mentor_on_demandContext m = new mentor_on_demandContext();
        // GET: api/Admin
        [HttpGet]
        public IEnumerable<Skills> Get()
        {
            try
            {
                return m.Skills.ToList();
            }
            catch(Exception e) {
                return null;
            }
        }

        // GET: api/Admin/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Admin
        [HttpPost]
        public void Post([FromBody] Skills value)
        {
            try
        { 
            m.Skills.Add(value);
            m.SaveChanges();
        }
            catch(Exception e) { }
        }

        // PUT: api/Admin/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

export interface Itraining
{
    id?:number
    uid?:number
    mid?:number
    sid?:number
    status?:string
}
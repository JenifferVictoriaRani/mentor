export interface ImentorVM
{
    id?:number
    
    skillName?:string
    selfRating?:number
    yearsOfExperience?:number
    trainngDelivered?:number
    facilitiesOffered?:string
}

export interface ImentorSkill
{
    mid?:number
    sid?:number
    msSelfRating?:number
    msYearsOfExperience?:number
    msTrainngDelivered?:number
    msFacilitiesOffered?:string
}
import { Component, OnInit } from '@angular/core';
import { Iskills } from '../Iskills';
import { MentorService } from '../mentor.service';
import { UserService } from '../user.service';
import { Imentordisplay } from '../Imentor';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
skill:Iskills[]
mentor:Imentordisplay[]
filteredMentor:Imentordisplay[]
flag:boolean=false
empty:boolean=false
msg:number
  constructor(private mentorSer:MentorService,private service:UserService) { }

  ngOnInit() 
  {
    this.flag=false
    this.service.getMentor().subscribe(x=>
      { debugger
        this.mentor=x as Imentordisplay[]
        this.filteredMentor=this.mentor
        this.empty=false
      }
    )
   
    this.mentorSer.getSkills().subscribe(x=>
      { debugger
        this.skill=x as Iskills[]
      })
  }
  onChange(id:number)
  {
    {{debugger}}
    this.service.getSpecificMentor(id).subscribe(x=>{ debugger
      this.filteredMentor=x as Imentordisplay[]
      if(this.filteredMentor.length==0)
      {
        this.empty=true
      }
      else{
        
        this.empty=false
      }
    });
    this.flag=false
    // this.service.sid=id
  }
  request(id:number,mid:number,sid:number)
  {
    debugger
    this.service.requestTrainer(mid,sid).subscribe(
      ()=>{
        this.flag=true
        this.empty=false
        this.msg= id
      }
    )
  }

}

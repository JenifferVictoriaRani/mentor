import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthserviceService } from './authservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService {

  isLoggedIn = false;
    
  constructor(private router : Router, private authService :AuthserviceService){
  }

  canActivate(route: ActivatedRouteSnapshot): boolean{        
      this.isLoggedIn = this.authService.loggedIn;
      //console.log("isLoggedIn: " + this.isLoggedIn);
      if(this.isLoggedIn){
          return true;
      }
      else{
          this.router.navigate(['login']);
          return false;
      }        
  }
}

export interface Imentor
{
    
    meName?:string
    meUsername?:string
    mePassword?:string
    meLinkedinUrl?:string 
  
  
    meYearsOfExperience?:number
}

export interface Imentordisplay
{
    id?:number
    mid?:number 
    skId?:number
    mentorName?:string
    skillName?:string
    selfRating?:number
    yearsOfExperience?:number
    facilitiesOffered?:string
}
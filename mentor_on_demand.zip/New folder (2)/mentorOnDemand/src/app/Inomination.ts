export interface Inomination
{
    id?:number
    username?:string
    contactNumber?:number
    sk_Name?:string
}
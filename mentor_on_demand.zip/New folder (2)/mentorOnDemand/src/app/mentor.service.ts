import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from './user.service';
import { ImentorVM, ImentorSkill } from './ImentorVM';
import { Itraining } from './Itraining';
import { Inomination } from './Inomination';
import { Iskills } from './Iskills';
import { AuthserviceService } from './authservice.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor(private http:HttpClient,private userSer:UserService,private authSer:AuthserviceService,private route:Router) { }

  mentorProfile()
  {
    return this.http.get<ImentorVM[]>('http://localhost:57690/api/mentor/getProfile/'+this.userSer.activeId)
  }
  mentorNomination()
  {
    return this.http.get<Inomination[]>('http://localhost:57690/api/mentor/getNomination/'+this.userSer.activeId)
  }
  getSkills()
  {
    return this.http.get<Iskills[]>('http://localhost:57690/api/mentor/getskill')
  }
  addSkills(value:ImentorSkill)
  {
    debugger
    return this.http.post<ImentorSkill>('http://localhost:57690/api/mentor',value)
  }
  logOut()
{
  this.authSer.logOut();
 localStorage.removeItem('token3')
 this.route.navigate(['login'])
}
}

import { Component, OnInit } from '@angular/core';
import { ImentorVM, ImentorSkill } from '../ImentorVM';
import { MentorService } from '../mentor.service';

import { Inomination } from '../Inomination';
import { Iskills } from '../Iskills';
import { UserService } from '../user.service';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {
profile:ImentorVM[]
nomination:Inomination[]
skill:Iskills[]
skills:ImentorSkill=
{
    mid:this.userSer.activeId,
    sid:null,
    msSelfRating:null,
    msYearsOfExperience:null,
    msTrainngDelivered:null,
    msFacilitiesOffered:null
}
msg:string=""
  constructor(private mentorSer:MentorService,private userSer:UserService) { }

  ngOnInit() {
    this.mentorSer.mentorProfile().subscribe(x=>{
      debugger
      this.profile = x as ImentorVM[]
    })
    this.mentorSer.mentorNomination().subscribe(x=>
      {
        debugger
        this.nomination=x as Inomination[]
      })
      this.mentorSer.getSkills().subscribe(
        x=>{ debugger
          this.skill=x as Iskills[]
        }
      )
  }

  addSkills(skills:ImentorSkill)
  {
    debugger
    this.mentorSer.addSkills(skills).subscribe(()=>
    {
      this.msg="skill added"
      this.mentorSer.mentorProfile().subscribe(x=>{
        debugger
        this.profile = x as ImentorVM[]
      })
    })
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { Iuser } from '../Icust';
import { AuthserviceService } from '../authservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user:Iuser=null
flag:boolean=true
  constructor(private route:Router,private userSer:UserService,private authService:AuthserviceService) { }

  ngOnInit() {
  }
  onSubmit(username:string,password:string,role:string)
  {
    if(role=='admin')
    {
      this.userSer.adminLogin(username,password).subscribe(
        (x:Iuser)=>{
          debugger
          this.user=x ;
          if(this.user==null)
          {
              this.flag=false

          }
          else
          {
            this.userSer.activeId=this.user.id;
            this.userSer.activeName=this.user.firstName
            this.authService.login();
            this.flag=true;
            this.userSer.status=true,this.userSer.GetTokenAdmin(this.user.firstName)
            this.route.navigate(['admin'])
          }  
        })
    }
    else if(role=='mentor')
    {
      this.userSer.mentorLogin(username,password).subscribe(
        (x:Iuser)=>{
          debugger
          this.user=x ;
          if(this.user==null)
          {
              this.flag=false

          }
          else
          {
            this.userSer.activeId=this.user.id;
            this.userSer.activeName=this.user.firstName
            this.userSer.status=true,this.userSer.GetTokenMentor(this.user.firstName)
            this.authService.login();
            this.flag=true
            this.route.navigate(['mentor'])
          }  
        })
    }
    else
    {
      this.userSer.userLogin(username,password).subscribe(
        (x:Iuser)=>{
          debugger
          this.user=x ;
          if(this.user==null)
          {
              this.flag=false

          }
          else
          {
            this.userSer.activeId=this.user.id;
            this.userSer.activeName=this.user.firstName
            this.userSer.status=true,this.userSer.GetTokenUser(this.user.firstName)
            this.authService.login();
            this.flag=true
            this.route.navigate(['user'])
          }  
        })
  }
 
}
}

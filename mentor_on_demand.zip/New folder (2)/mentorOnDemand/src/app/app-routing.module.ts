import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { RegisterComponent } from './register/register.component';
import { MentorComponent } from './mentor/mentor.component';
import { UserComponent } from './user/user.component';
import { AuthguardService } from './authguard.service';


const routes: Routes = [
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'admin',
    component:AdminComponent,canActivate: [AuthguardService]
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'mentor',
    component:MentorComponent,canActivate: [AuthguardService]
  },
  {
    path:'user',
    component:UserComponent,canActivate: [AuthguardService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export interface Iadmin
{
    id?:number
    adUsername?:string
    adPassword?:string
}
import { Component, OnInit } from '@angular/core';
import { Imentor } from '../Imentor';

import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { IUser } from '../IUser';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

user:Imentor=
{
 
  meName:null,
  meUsername:null,
  mePassword:null,
  meLinkedinUrl:null,
  meYearsOfExperience:null
}
user1:IUser=
{
 
    usUsername:null,
    usPassword:null,
    firstName:null,
    lastName:null,
    contactNumber:null
}
flag:boolean=false
  constructor(private route:Router,private userSer:UserService) { }

  ngOnInit() {
  }
addMentor(user:Imentor)
{
  debugger
  this.userSer.registerMentor(user).subscribe(
    
  )
  }
  addUser(user:IUser)
{
  debugger
  this.userSer.registerUser(user).subscribe(
  
  )
  }
}
export interface Iskills
{
    id?:number
    skName?:string
    skToc?:string
    skDuration?:number
    skPrerequistes?:string
}
import { Component, OnInit } from '@angular/core';
import { ImentorVM } from '../ImentorVM';
import { UserService } from '../user.service';
import { AdminService } from '../admin.service';
import { Iskills } from '../Iskills';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private adminSer:AdminService,private userSer:UserService) { }
mentorDetails:Iskills[]
  ngOnInit() {
    this.adminSer.getMentorDetails().subscribe(
      x=>{
        this.mentorDetails=x as Iskills[]
      }
    )
  }

}

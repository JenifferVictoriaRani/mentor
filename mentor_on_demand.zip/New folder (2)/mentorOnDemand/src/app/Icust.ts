export interface Iuser
{
    id?:number
    username?:string
    password?:string
    firstName?:string
    lastName?:string
    contactNumber?:number 
    regCode?:number
    active?:string
    resetPassword?:string
    regDatetime?:Date
    linkedinUrl?:string 
    regDateTime?:Date
    yearsOfExperience?:number
}
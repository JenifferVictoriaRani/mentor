import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ImentorVM } from './ImentorVM';
import { Observable } from 'rxjs';
import { Iskills } from './Iskills';
import { Router } from '@angular/router';
import { AuthserviceService } from './authservice.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  readonly adminUrl='http://localhost:55421/api/admin';
  constructor(private http:HttpClient,private route:Router,private authSer:AuthserviceService) { }
  getMentorDetails():Observable<{}>
  {
    return this.http.get<Iskills[]>(this.adminUrl)
  }
  logOut()
  {
    this.authSer.logOut();
   localStorage.removeItem('token1')
   this.route.navigate(['login'])
  }
}

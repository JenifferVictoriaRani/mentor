export interface IUser
{
    
    usUsername?:string
    usPassword?:string
    firstName?:string
    lastName?:string
    contactNumber?:number 
   
}
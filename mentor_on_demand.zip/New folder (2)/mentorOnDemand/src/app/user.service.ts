import { Injectable } from '@angular/core';
import { Router, RouteReuseStrategy } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Imentor, Imentordisplay } from './Imentor';
import { Iuser } from './Icust';
import { AuthserviceService } from './authservice.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

readonly url='http://localhost:57324/api/'
readonly authUrl='http://localhost:55561/api/Auth/'

status:boolean
activeId:number 
activeName:string

  constructor(private route:Router,private http:HttpClient,private authSer:AuthserviceService) { }

  adminLogin(username:string,pass:string)
  { 
    return this.http.get<Iuser>(this.url+'Admin/'+username+'/'+pass)
  
  }
  GetTokenAdmin(username:string)
  { debugger
    if(this.status==true)
    {
      this.http.get(this.authUrl+'GetAdminToken/'+username).
      subscribe((res:any)=>{
        localStorage.setItem('token1',res.token);
        console.log(res.token);
      })
    }
  }
  mentorLogin(username:string,pass:string)
  {
    return this.http.get<Iuser>(this.url+'Mentor/'+username+'/'+pass)
  }
  GetTokenUser(username:string)
  {
    if(this.status==true)
    {
      this.http.get(this.authUrl+'GetUserToken/'+username).
      subscribe((res:any)=>{
        localStorage.setItem('token2',res.token);
        console.log(res.token);
        
      })
    }
  }
  userLogin(username:string,pass:string)
  { debugger
    return this.http.get<Iuser>(this.url+'User/'+username+'/'+pass)
   
  }
  GetTokenMentor(username:string)
  {
    if(this.status==true)
    {
      this.http.get(this.authUrl+'GetMentorToken/'+username).
      subscribe((res:any)=>{
        localStorage.setItem('token3',res.token);
        console.log(res.token);
       
      })
    }
  }
  registerMentor(value:Imentor)
  {
    debugger
    return this.http.post('http://localhost:57324/api/Mentor',value)
    }
  registerUser(value:Iuser)
  {
    debugger
    return this.http.post('http://localhost:57324/api/User',value)
  }
  getSpecificMentor(id:number)
  {
    return this.http.get<Imentordisplay>('http://localhost:57137/api/user/searchMentor/'+id)
  }
  getMentor()
  {
    return this.http.get<Imentordisplay[]>('http://localhost:57137/api/user/displayMentor')
  }
  requestTrainer(mid:number,sid:number)
  { debugger
    return this.http.post('http://localhost:57137/api/user/'+this.activeId+'/'+mid+'/'+sid,{ headers: new HttpHeaders({ 'Content-Type': 'application/json'}) })
  }
logOut()
{
  this.authSer.logOut();
 localStorage.removeItem('token2')
 this.route.navigate(['login'])
}
}

using login.Controllers;
using login.Models;
using NUnit.Framework;
using System.Collections.Generic;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GetAllAdminCorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new AdminController();

            var result = controller.Get("admin@gmail.com","admin") as Admin;
            Assert.AreEqual("admin@gmail.com",result.AdUsername);
        }
        [Test]
        public void GetAllAdminIncorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new AdminController();

            var result = controller.Get("admin@gmail.com", "admin") as Admin;
            Assert.AreEqual("admin1@gmail.com", result.AdUsername);
        }
        [Test]
        public void GetAllMentorCorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new MentorController();

            var result = controller.Get("jeniffer@gmail.com", "jeni") as Mentor;
            Assert.AreEqual("Jeniffer@gmail.com", result.MeUsername);
        }
        [Test]
        public void GetAllMentorIncorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new MentorController();

            var result = controller.Get("jeniffer@gmail.com", "jeni") as Mentor;
            Assert.AreEqual("jeniffer@gmail.com", result.MeUsername);
        }
        [Test]
        public void GetAllUserCorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new UserController();

            var result = controller.Get("jeniffer@gmail.com", "jeni") as UserDetails;
            Assert.AreEqual("Jeniffer@gmail.com", result.UsUsername);
        }
        [Test]
        public void GetAllUserIncorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new UserController();

            var result = controller.Get("jeniffer@gmail.com", "jeni") as UserDetails;
            Assert.AreEqual("admin@gmail.com", result.UsUsername);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using login.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace login.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        mentor_on_demandContext M = new mentor_on_demandContext();

        [HttpGet]
        public IEnumerable<Admin> Get()
        {
            try { 
            return M.Admin.ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        // GET: api/Admin/5
        [HttpGet("{username}/{pass}", Name = "GetAdmin")]
        public Admin Get(string username, string pass)
        {
            try { 
            return M.Admin.FromSql("AdminLogin '" + username + "','" + pass + "'").SingleOrDefault();
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}
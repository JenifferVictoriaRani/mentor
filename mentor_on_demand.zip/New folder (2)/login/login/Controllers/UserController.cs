﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using login.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace login.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        mentor_on_demandContext M = new mentor_on_demandContext();


        // GET: api/User
        [HttpGet]
        public IEnumerable<UserDetails> Get()
        {
            try { 
            return M.UserDetails.ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        // GET: api/User/5
        [HttpGet("{username}/{pass}", Name = "Getuser")]

        public UserDetails Get(string username, string pass)
        {
            try { 
            return M.UserDetails.FromSql("UserLogin '" + username + "','" + pass + "'").SingleOrDefault();
            }
            catch (Exception e)
            {
                return null;
            }

        }

        // POST: api/User
        [HttpPost]
        public void Post([FromBody] UserDetails value)
        {
            try { 
            M.Database.ExecuteSqlCommand("UserRegister '" + value.UsUsername + "','" + value.UsPassword + "','" + value.FirstName + "','" + value.LastName + "'," + value.ContactNumber);
            }
            catch (Exception e)
            {
               
            }
        }
    }
}
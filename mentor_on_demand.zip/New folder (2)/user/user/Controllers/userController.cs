﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using user.Models;
using Microsoft.EntityFrameworkCore;

namespace user.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        mentor_on_DemandContext m = new mentor_on_DemandContext();
        // GET: api/user
        [HttpGet]
        [Route("displayMentor")]
        public IEnumerable<mentorDisplay> Get()
        {
            try { 
            return m.mentorDisplay.FromSql("displayMentor").ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        [HttpGet]
        [Route("searchMentor/{id}")]
        public IEnumerable<mentorDisplay> search(int id)
        {
            try { 
            return m.mentorDisplay.FromSql("searchMentor "+id).ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        // GET: api/user/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/user
        [HttpPost("{uid}/{mid}/{sid}")]
        public void Post(int uid, int mid, int sid)
        {
            try { 
            m.Database.ExecuteSqlCommand("nominate " + uid + "," + mid + "," + sid);
            }
            catch (Exception e)
            {
               
            }
        }

        // PUT: api/user/5
        [HttpPut]
        public void Put()
        {
            
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

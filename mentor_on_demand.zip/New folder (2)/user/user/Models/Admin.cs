﻿using System;
using System.Collections.Generic;

namespace user.Models
{
    public partial class Admin
    {
        public int Id { get; set; }
        public string AdUsername { get; set; }
        public string AdPassword { get; set; }
    }
}

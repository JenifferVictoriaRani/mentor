﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace user.Models
{
    public class mentorDisplay
    {
        [Key]
        public int Id { get; set; }
        public int Mid { get; set; }
        public int SkId { get; set; }
        public string MentorName { get; set; }
        public string SkillName { get; set; }
        public decimal SelfRating { get; set; }
        public int? YearsOfExperience { get; set; }
        public string FacilitiesOffered { get; set; }

    }
}

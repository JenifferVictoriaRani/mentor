﻿using System;
using System.Collections.Generic;

namespace user.Models
{
    public partial class UserDetails
    {
        public UserDetails()
        {
            Training = new HashSet<Training>();
        }

        public int Id { get; set; }
        public string UsUsername { get; set; }
        public string UsPassword { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal ContactNumber { get; set; }
        public string RegCode { get; set; }
        public string Active { get; set; }
        public string ResetPassword { get; set; }
        public DateTime RegDatetime { get; set; }

        public ICollection<Training> Training { get; set; }
    }
}

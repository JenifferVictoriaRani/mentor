﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace user.Models
{
    public partial class mentor_on_DemandContext : DbContext
    {
        public mentor_on_DemandContext()
        {
        }

        public mentor_on_DemandContext(DbContextOptions<mentor_on_DemandContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<Mentor> Mentor { get; set; }
        public virtual DbSet<MentorSkills> MentorSkills { get; set; }
        public virtual DbSet<Skills> Skills { get; set; }
        public virtual DbSet<Training> Training { get; set; }
        public virtual DbSet<UserDetails> UserDetails { get; set; }
        public virtual DbSet<mentorDisplay> mentorDisplay { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(local);Database=mentor_on_Demand;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.Property(e => e.AdPassword)
                    .HasColumnName("Ad_Password")
                    .HasMaxLength(50);

                entity.Property(e => e.AdUsername)
                    .HasColumnName("Ad_Username")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Mentor>(entity =>
            {
                entity.HasIndex(e => e.MeUsername)
                    .HasName("UQ__mentor__5D59886D036683A5")
                    .IsUnique();

                entity.Property(e => e.MeActive)
                    .HasColumnName("me_Active")
                    .HasMaxLength(10);

                entity.Property(e => e.MeLinkedinUrl)
                    .IsRequired()
                    .HasColumnName("me_LinkedinURL")
                    .HasMaxLength(100);

                entity.Property(e => e.MeName)
                    .HasColumnName("me_Name")
                    .HasMaxLength(50);

                entity.Property(e => e.MePassword)
                    .IsRequired()
                    .HasColumnName("me_Password")
                    .HasMaxLength(50);

                entity.Property(e => e.MeRegCode)
                    .HasColumnName("me_Reg_Code")
                    .HasMaxLength(10);

                entity.Property(e => e.MeRegDateTime)
                    .HasColumnName("me_Reg_DateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.MeUsername)
                    .IsRequired()
                    .HasColumnName("me_Username")
                    .HasMaxLength(50);

                entity.Property(e => e.MeYearsOfExperience).HasColumnName("me_Years_Of_Experience");
            });

            modelBuilder.Entity<MentorSkills>(entity =>
            {
                entity.ToTable("Mentor_Skills");

                entity.Property(e => e.Mid).HasColumnName("MId");

                entity.Property(e => e.MsFacilitiesOffered)
                    .HasColumnName("ms_Facilities_Offered")
                    .HasMaxLength(100);

                entity.Property(e => e.MsSelfRating)
                    .HasColumnName("ms_SelfRating")
                    .HasColumnType("decimal(3, 1)");

                entity.Property(e => e.MsTrainngDelivered).HasColumnName("ms_Trainng_Delivered");

                entity.Property(e => e.MsYearsOfExperience).HasColumnName("ms_Years_Of_Experience");

                entity.Property(e => e.Sid).HasColumnName("SId");

                entity.HasOne(d => d.M)
                    .WithMany(p => p.MentorSkills)
                    .HasForeignKey(d => d.Mid)
                    .HasConstraintName("ms_me_FK");

                entity.HasOne(d => d.S)
                    .WithMany(p => p.MentorSkills)
                    .HasForeignKey(d => d.Sid)
                    .HasConstraintName("FK_Mentor_Skills_Skills");
            });

            modelBuilder.Entity<Skills>(entity =>
            {
                entity.HasIndex(e => e.SkName)
                    .HasName("UQ__skills__F639279DE15B7177")
                    .IsUnique();

                entity.Property(e => e.SkDuration).HasColumnName("sk_Duration");

                entity.Property(e => e.SkName)
                    .IsRequired()
                    .HasColumnName("sk_Name")
                    .HasMaxLength(50);

                entity.Property(e => e.SkPrerequistes)
                    .HasColumnName("sk_Prerequistes")
                    .HasMaxLength(50);

                entity.Property(e => e.SkToc)
                    .IsRequired()
                    .HasColumnName("sk_TOC")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Training>(entity =>
            {
                entity.Property(e => e.Mid).HasColumnName("MId");

                entity.Property(e => e.Sid).HasColumnName("SId");

                entity.Property(e => e.Status).HasMaxLength(20);

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.HasOne(d => d.M)
                    .WithMany(p => p.Training)
                    .HasForeignKey(d => d.Mid)
                    .HasConstraintName("tr_me_FK");

                entity.HasOne(d => d.S)
                    .WithMany(p => p.Training)
                    .HasForeignKey(d => d.Sid)
                    .HasConstraintName("tr_sk_FK");

                entity.HasOne(d => d.U)
                    .WithMany(p => p.Training)
                    .HasForeignKey(d => d.Uid)
                    .HasConstraintName("tr_us_FK");
            });

            modelBuilder.Entity<UserDetails>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active).HasMaxLength(50);

                entity.Property(e => e.ContactNumber).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RegCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RegDatetime).HasColumnType("date");

                entity.Property(e => e.ResetPassword).HasMaxLength(50);

                entity.Property(e => e.UsPassword)
                    .IsRequired()
                    .HasColumnName("us_Password")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UsUsername)
                    .IsRequired()
                    .HasColumnName("us_Username")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }
    }
}

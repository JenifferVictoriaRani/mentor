﻿using System;
using System.Collections.Generic;

namespace user.Models
{
    public partial class Mentor
    {
        public Mentor()
        {
            MentorSkills = new HashSet<MentorSkills>();
            Training = new HashSet<Training>();
        }

        public int Id { get; set; }
        public string MeName { get; set; }
        public string MeUsername { get; set; }
        public string MePassword { get; set; }
        public string MeLinkedinUrl { get; set; }
        public DateTime MeRegDateTime { get; set; }
        public string MeRegCode { get; set; }
        public int? MeYearsOfExperience { get; set; }
        public string MeActive { get; set; }

        public ICollection<MentorSkills> MentorSkills { get; set; }
        public ICollection<Training> Training { get; set; }
    }
}

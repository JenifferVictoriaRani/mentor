
alter proc MentorRegister(@name nvarchar(40),@username nvarchar(40),@pass nvarchar(40),@url nvarchar(40),@years int)
as
insert into mentor values (@name,@username,@pass,@url,GETDATE(),null,@years,'yes') 

alter proc UserRegister(@name nvarchar(50),@pass nvarchar(50),@fname nvarchar(50),@lname nvarchar(5),@contact numeric(10,0))
as
insert into UserDetails values(@name,@pass,@fname,@lname,@contact,null,'yes',null,GETDATE())

alter proc MentorRegister(@username nvarchar(40),@pass nvarchar(40),@url nvarchar(40),@date datetime,@years int)
as
insert into mentor values (@username,@pass,@url,@date,null,@years,'yes')

alter proc UserRegister(@name nvarchar(50),@pass nvarchar(50),@fname nvarchar(50),@lname nvarchar(5),@contact numeric(10,0),@date datetime)
as
insert into UserDetails values(@name,@pass,@fname,@lname,@contact,null,'yes',null,@date)
>>>>>>> ff410ba68798ce8073f4eec2850a6c7b71d316e7

alter proc AdminLogin(@user nvarchar(50),@pass nvarchar(50))
as
select * from admin where Ad_Username=@user and Ad_Password=@pass

alter proc MentorLogin(@user nvarchar(50),@pass nvarchar(50))
as
select * from mentor where me_Username=@user and me_Password=@pass

alter proc UserLogin(@user nvarchar(50),@pass nvarchar(50))
as
select * from UserDetails where us_Username=@user and us_Password=@pass

--alter proc adminlogin1(@user nvarchar(50))
--as
--select Password from admin where Username=@user

--alter proc MentorLogin1(@user nvarchar(50))
--as
--select Password from mentor where Username=@user

--alter proc UserLogin1(@user nvarchar(50))
--as
--select password from UserDetails where UserName=@user

insert into admin values('admin@gmail.com','admin')


execute UserRegister 'Jeniffer@gmail.com','jeni','jeniffer','r','9887988799','2019-02-10'


execute MentorRegister 'Jeniffer@gmail.com','jeni','xxx','2019-02-10',8

select * from admin

select * from mentor

<<<<<<< HEAD
select * from UserDetails

alter proc skillname(@name varchar(20))
as
select Id from Skills where Name like % '@name'

execute displayMentor

alter proc displayMentor 
as
select Mentor_Skills.Id as Id,Mentor.Id as Mid, Skills.Id as SkId,Mentor.me_Name as MentorName,skills.sk_Name as SkillName,Mentor_Skills.ms_SelfRating as SelfRating,Mentor_Skills.ms_Years_Of_Experience as YearsOfExperience,Mentor_Skills.ms_Facilities_Offered as FacilitiesOffered from Mentor,Mentor_Skills,Skills where Skills.Id=Mentor_Skills.SId and Mentor_Skills.MId=Mentor.Id

create proc searchMentor(@skid int)
as
select Mentor_Skills.Id as Id,Mentor.Id as Mid, Skills.Id as SkId,Mentor.me_Name as MentorName,skills.sk_Name as SkillName,Mentor_Skills.ms_SelfRating as SelfRating,Mentor_Skills.ms_Years_Of_Experience as YearsOfExperience,Mentor_Skills.ms_Facilities_Offered as FacilitiesOffered from Mentor,Mentor_Skills,Skills where Skills.Id=Mentor_Skills.SId and Mentor_Skills.MId=Mentor.Id and Skills.Id=@skid

execute searchMentor 1000

alter proc mentorProfile(@id int)
as
select Mentor_Skills.MId as Id,Skills.sk_Name as SkillName,Mentor_Skills.ms_SelfRating as SelfRating ,Mentor_Skills.ms_Years_Of_Experience as YearsOfExperience,Mentor_Skills.ms_Trainng_Delivered as TrainngDelivered,Mentor_Skills.ms_Facilities_Offered as FacilitiesOffered from Mentor_Skills,Skills where Mentor_Skills.SId=Skills.Id and Mentor_Skills.MId=@id 

execute mentorProfile 1000

insert into mentor values ('hi@gmail.com','hi','hjg',GetDate(),'null',8,'yes')

alter proc nomination(@mid int)
as
select Training.Id,UserDetails.FirstName as username,UserDetails.ContactNumber,Skills.sk_Name from UserDetails,Skills,Training where Mid=@mid and Training.UId=UserDetails.id and Training.SId=Skills.Id

execute nomination 1000

execute nominate 2,1000,1000

create proc nominate(@uid int,@mid int,@sid int)
as
insert into Training values(@uid,@mid,@sid,'pending')